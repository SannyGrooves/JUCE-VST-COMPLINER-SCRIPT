[CmdletBinding()]
param(
    [ValidateSet("Release", "Debug")]
    [string]$Config = "Release",
    [switch]$Clean,
    [switch]$Install
)

$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

# --- 1. Tools on PATH -------------------------------------------------------
$missing = $false

if (-not (Get-Command cmake -ErrorAction SilentlyContinue)) {
    Write-Host "CMake was not found on PATH. Install it with:" -ForegroundColor Red
    Write-Host "    winget install Kitware.CMake" -ForegroundColor Red
    $missing = $true
}

if (-not (Get-Command git -ErrorAction SilentlyContinue)) {
    Write-Host "Git was not found on PATH. Install it with:" -ForegroundColor Red
    Write-Host "    winget install Git.Git" -ForegroundColor Red
    $missing = $true
}

if ($missing) {
    Write-Host "After installing, open a NEW PowerShell window and run this script again." -ForegroundColor Red
    exit 1
}

# --- 2. Visual Studio C++ tools ----------------------------------------------
$vswhere = Join-Path ${env:ProgramFiles(x86)} "Microsoft Visual Studio\Installer\vswhere.exe"
$vsPath = $null

if (Test-Path $vswhere) {
    $vsPath = & $vswhere -latest -products * `
        -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 `
        -property installationPath
    $vsPath = @($vsPath)[0]
}

if (-not $vsPath) {
    Write-Host "Visual Studio with the C++ build tools was not found. Install it with:" -ForegroundColor Red
    Write-Host '    winget install Microsoft.VisualStudio.2022.BuildTools --override "--wait --passive --add Microsoft.VisualStudio.Workload.VCTools --includeRecommended"' -ForegroundColor Red
    exit 1
}

Write-Host "Using Visual Studio at: $vsPath"

# --- 3. Clean ----------------------------------------------------------------
if ($Clean -and (Test-Path "build")) {
    Write-Host "Removing build folder..."
    Remove-Item -Recurse -Force "build"
}

# --- 4. Configure and build --------------------------------------------------
Write-Host "Configuring..."
& cmake -B build -S .
if ($LASTEXITCODE -ne 0) {
    Write-Host "CMake configure failed." -ForegroundColor Red
    exit $LASTEXITCODE
}

Write-Host "Building ($Config)..."
& cmake --build build --config $Config --parallel
if ($LASTEXITCODE -ne 0) {
    Write-Host "Build failed." -ForegroundColor Red
    exit $LASTEXITCODE
}

# --- 5. Locate the VST3 bundle ------------------------------------------------
$vst3 = Get-ChildItem -Path "build" -Recurse -Directory -Filter "*.vst3" |
    Where-Object { $_.FullName -match [regex]::Escape($Config) } |
    Select-Object -First 1

if (-not $vst3) {
    Write-Host "Build finished, but no .vst3 folder for configuration '$Config' was found under build." -ForegroundColor Red
    exit 1
}

Write-Host "VST3 built: $($vst3.FullName)" -ForegroundColor Green

# --- 6. Optional install -------------------------------------------------------
if ($Install) {
    $identity  = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    $isAdmin   = $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)

    if (-not $isAdmin) {
        Write-Host "Installing needs Administrator rights. Re-run this script from an elevated PowerShell." -ForegroundColor Yellow
        exit 1
    }

    $dest = Join-Path $env:CommonProgramFiles "VST3"
    if (-not (Test-Path $dest)) {
        New-Item -ItemType Directory -Path $dest | Out-Null
    }

    Copy-Item -Path $vst3.FullName -Destination $dest -Recurse -Force
    Write-Host "Installed to: $dest" -ForegroundColor Green
}
